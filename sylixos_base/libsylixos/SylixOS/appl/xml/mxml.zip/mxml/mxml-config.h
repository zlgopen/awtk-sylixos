/*
 * "$Id: config.h.in 387 2009-04-18 17:05:52Z mike $"
 *
 * Configuration file for Mini-XML, a small XML-like file parsing library.
 *
 * Copyright 2003-2009 by Michael Sweet.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/*
 * Include necessary headers...
 */

#ifndef __MXML_CONFIG_H
#define __MXML_CONFIG_H

/**************************** HANHUI ***************************/
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdarg.h"
#include "ctype.h"
/**************************** HANHUI ***************************/


/*
 * Version number...
 */

#define MXML_VERSION	""


/*
 * Inline function support...
 */

/**************************** HANHUI ***************************/
#ifndef __GNUC__
#define inline
#endif
/**************************** HANHUI ***************************/


/*
 * Long long support...
 */

#undef HAVE_LONG_LONG


/*
 * Do we have the snprintf() and vsnprintf() functions?
 */

/**************************** HANHUI ***************************/
#define HAVE_SNPRINTF       1
#define HAVE_VSNPRINTF      1
/**************************** HANHUI ***************************/


/*
 * Do we have the strXXX() functions?
 */

/**************************** HANHUI ***************************/
#define HAVE_STRDUP         1
/**************************** HANHUI ***************************/


/*
 * Do we have threading support?
 */

#undef HAVE_PTHREAD_H


/*
 * Define prototypes for string functions as needed...
 */

#  ifndef HAVE_STRDUP
extern char	*_mxml_strdup(const char *);
#    define strdup _mxml_strdup
#  endif /* !HAVE_STRDUP */

extern char	*_mxml_strdupf(const char *, ...);
extern char	*_mxml_vstrdupf(const char *, va_list);

#  ifndef HAVE_SNPRINTF
extern int	_mxml_snprintf(char *, size_t, const char *, ...);
#    define snprintf _mxml_snprintf
#  endif /* !HAVE_SNPRINTF */

#  ifndef HAVE_VSNPRINTF
extern int	_mxml_vsnprintf(char *, size_t, const char *, va_list);
#    define vsnprintf _mxml_vsnprintf
#  endif /* !HAVE_VSNPRINTF */

#endif /* __MXML_CONFIG_H */
/*
 * End of "$Id: config.h.in 387 2009-04-18 17:05:52Z mike $".
 */
