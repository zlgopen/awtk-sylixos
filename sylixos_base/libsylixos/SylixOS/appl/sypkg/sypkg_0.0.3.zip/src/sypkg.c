/*
 * sylixos .deb install tools.
 *
 * sypkg tool.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#include "sypkg.h"

/* global variable */
char    file_copy_buf[PATH_MAX + 1];
char    list_file[PATH_MAX + 1];
char    package_dir[PATH_MAX + 1];
FILE   *fp_list = NULL;
struct deb_info debinfo;

/*
 *  init sypkg tool work directory.
 *  return SYPKG_OK: init ok. SYPKG_ERR: can not init.
 */
static int sypkg_workdirectory_init (void)
{
	if (access(SYPKG_DIRECTORY, R_OK) < 0) {
		SYPKG_PRINT_ERROR("sypkg can not access path : %s\n", SYPKG_DIRECTORY);
		return	(SYPKG_ERR);
	}

	if (access(SYPKG_TMP, R_OK) < 0) {
		if (mkdir(SYPKG_TMP, SYPKG_DEFAULT_DIR_PERM) < 0) {
			SYPKG_PRINT_ERROR("sypkg can not make tmp directory : %s\n", SYPKG_TMP);
			return	(SYPKG_ERR);
		}
	}

	return	(SYPKG_OK);
}

/*
 *  lock the sypkg tool work directory.
 *  retry_ms: retry timeouts millisecond
 *  times: retry times
 *  return SYPKG_OK: init ok. SYPKG_ERR: can not lock.
 */
static int sypkg_workdirectory_lock (int retry_ms, int times)
{
    int fd;

	for (; times > 0; times--) {
	    fd = creat(SYPKG_LOCK_FILE, SYPKG_DEFAULT_FILE_PERM);
		if (fd < 0) {
			usleep(retry_ms * 1000);
		} else {
		    close(fd);
			return	(SYPKG_OK);
		}
	}

	SYPKG_PRINT_ERROR("sypkg can not lock : %s\n", SYPKG_LOCK_FILE);
	return	(SYPKG_ERR);
}

/*
 *  remove tmp files
 */
static void sypkg_workdirectory_rm_tmp (void)
{
	remove_all_files(SYPKG_TMP, 0); /* do not remove SYPKG_TMP, */
}

/*
 *  unlock the sypkg tool work directory.
 *  return SYPKG_OK: init ok. SYPKG_ERR: can not lock.
 */
static int sypkg_workdirectory_unlock (void)
{
	unlink(SYPKG_LOCK_FILE);
	return	(SYPKG_OK);
}

/*
 *  unpackage data file callback
 *  filename:unpackage file name
 */
static void sypkg_cb (const char *filename)
{
    fprintf(fp_list, "%s\n", filename);
}

/*
 *  install a deb software package.
 *  deb   package name
 */
static int sypkg_install (const char *deb)
{
	int		error;

	if (ar_extract(deb, SYPKG_TMP, NULL, NULL) < SYPKG_OK) {
		return	(SYPKG_ERR);
	}

	sypkg_debinfo_clear(&debinfo);

	/* release control package */
	SYPKG_PRINT("unpackage control files...\n");
	if (access(SYPKG_CTL_FILE_PKG_TARGZ, R_OK) == 0) {
	    untargz(SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_TMP, NULL);

	} else if (access(SYPKG_CTL_FILE_PKG_TAR, R_OK) == 0) {
	    untar(SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_TMP, NULL);

	} else {
	    SYPKG_PRINT_ERROR("sypkg can not find : %s or %s\n",
	            SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_CTL_FILE_PKG_TAR);
	    return  (SYPKG_ERR);
	}

	/* get/print configration */
	SYPKG_PRINT("configration:\n");
	system("cat " SYPKG_TMP "/" SYPKG_CTL_FILENAME);

	if (sypkg_debinfo_analyse_file(&debinfo, SYPKG_TMP "/" SYPKG_CTL_FILENAME)) {
		SYPKG_PRINT_ERROR("sypkg can not analyse control file.\n");
		return  (SYPKG_ERR);
	}
	if (debinfo.package == NULL) {
		SYPKG_PRINT_ERROR("sypkg can not get \"package\".\n");
		return  (SYPKG_ERR);
	}

	/* create package directory */
	snprintf(package_dir, sizeof(package_dir), "%s/%s",
             SYPKG_DIRECTORY, debinfo.package);
	if (mkdir(package_dir, SYPKG_DEFAULT_DIR_PERM) < 0) {
        SYPKG_PRINT_ERROR("sypkg can not create %s directory.\n", package_dir);
        return  (SYPKG_ERR);
    }

	/* create list file */
	snprintf(list_file, sizeof(list_file), "%s/%s/%s",
	         SYPKG_DIRECTORY, debinfo.package, SYPKG_RMLIST_FILENAME);
	fp_list = fopen(list_file, "w");
	if (!fp_list) {
	    SYPKG_PRINT_ERROR("sypkg can not create list file : %s\n", list_file);
	    return  (SYPKG_ERR);
	}

	/* run scripte */
	if (access(SYPKG_TMP "/" SYPKG_PREINST, R_OK) == 0) {
	    SYPKG_PRINT("run scripte %s ...\n", SYPKG_PREINST);
#ifdef SYLIXOS
	    system("shfile " SYPKG_TMP "/" SYPKG_PREINST);
#endif
	}

	/* release data package */
	SYPKG_PRINT("unpackage data files...\n");
	if (access(SYPKG_DATA_FILE_PKG_TARGZ, R_OK) == 0) {
	    error = untargz(SYPKG_DATA_FILE_PKG_TARGZ, "/.", sypkg_cb); /* start from root */
	    fclose(fp_list);
	    fp_list = NULL;

	} else if (access(SYPKG_DATA_FILE_PKG_TAR, R_OK) == 0) {
	    error = untar(SYPKG_DATA_FILE_PKG_TAR, "/.", sypkg_cb); /* start from root */
	    fclose(fp_list);
	    fp_list = NULL;

	} else {
	    SYPKG_PRINT_ERROR("sypkg can not find data package : %s or %s\n",
	            SYPKG_DATA_FILE_PKG_TARGZ, SYPKG_DATA_FILE_PKG_TAR);
	    return  (SYPKG_ERR);
	}

	/* cpy info file */
    if (error == SYPKG_OK) {
        snprintf(file_copy_buf, sizeof(file_copy_buf), "%s/" SYPKG_CTL_FILENAME, package_dir);
        error = file_copy(file_copy_buf, SYPKG_TMP "/" SYPKG_CTL_FILENAME);
        if (error) {
            goto    __unpackage_and_copy_end;
        }
        if (access(SYPKG_TMP "/" SYPKG_PRERM, R_OK) == 0) {
            snprintf(file_copy_buf, sizeof(file_copy_buf), "%s/" SYPKG_PRERM, package_dir);
            error = file_copy(file_copy_buf, SYPKG_TMP "/" SYPKG_PRERM);
        }
        if (error) {
            goto    __unpackage_and_copy_end;
        }
        if (access(SYPKG_TMP "/" SYPKG_POSTRM, R_OK) == 0) {
            snprintf(file_copy_buf, sizeof(file_copy_buf), "%s/" SYPKG_POSTRM, package_dir);
            error = file_copy(file_copy_buf, SYPKG_TMP "/" SYPKG_POSTRM);
        }
    }

__unpackage_and_copy_end:
	if (error) {
	    remove_list_files(list_file);
	    remove_all_files(package_dir, 1);
	    return  (SYPKG_ERR);
	}

	/* run scripte */
	if (access(SYPKG_TMP "/" SYPKG_POSTINST, R_OK) == 0) {
	    SYPKG_PRINT("run scripte %s ...\n", SYPKG_POSTINST);
#ifdef SYLIXOS
	    system("shfile " SYPKG_TMP "/" SYPKG_POSTINST);
#endif
	}

	/* clear debinfo */
	sypkg_debinfo_clear(&debinfo);

	return	(SYPKG_OK);
}

/*
 *  uninstall a software.
 *  name : software name
 */
static int sypkg_uninstall (const char *name)
{
    char    path[PATH_MAX + 1];

    sypkg_debinfo_clear(&debinfo);

    /* check is the software has been install */
    snprintf(package_dir, sizeof(package_dir), "%s/%s",
             SYPKG_DIRECTORY, name);
    if (access(package_dir, R_OK)) {
        SYPKG_PRINT_ERROR("sypkg can not find software %s\n", name);
        return  (SYPKG_ERR);
    }

    snprintf(path, sizeof(path), "%s/%s", package_dir, SYPKG_CTL_FILENAME);
    if (sypkg_debinfo_analyse_file(&debinfo, path)) {
        SYPKG_PRINT_ERROR("sypkg can not analyse control file.\n");
        return  (SYPKG_ERR);
    }

    /* get list file name */
    snprintf(list_file, sizeof(list_file), "%s/%s/%s",
             SYPKG_DIRECTORY, debinfo.package, SYPKG_RMLIST_FILENAME);

    /* run scripte */
    snprintf(path, sizeof(path), "%s/%s", package_dir, SYPKG_PRERM);
    if (access(path, R_OK) == 0) {
        SYPKG_PRINT("run scripte %s ...\n", SYPKG_PRERM);
#ifdef SYLIXOS
        snprintf(path, sizeof(path), "shfile %s/%s", package_dir, SYPKG_PRERM);
        system(path);
#endif
    }

    remove_list_files(list_file);

    /* run scripte */
    snprintf(path, sizeof(path), "%s/%s", package_dir, SYPKG_POSTRM);
    if (access(path, R_OK) == 0) {
        SYPKG_PRINT("run scripte %s ...\n", SYPKG_POSTRM);
#ifdef SYLIXOS
        snprintf(path, sizeof(path), "shfile %s/%s", package_dir, SYPKG_POSTRM);
        system(path);
#endif
    }

    remove_all_files(package_dir, 1);

    /* clear debinfo */
    sypkg_debinfo_clear(&debinfo);

	return	(SYPKG_OK);
}

/*
 *  remove a software with list file (Danger!).
 *  list : list file name
 */
static int sypkg_remove (const char *list)
{
    if (access(list, R_OK) == 0) {
        remove_list_files(list);
    } else {
        SYPKG_PRINT_ERROR("sypkg can not find list : %s\n", list);
        return  (SYPKG_ERR);
    }
    return  (SYPKG_OK);
}

/*
 *  get a deb software package infomation.
 *  deb   package name
 */
static int sypkg_info (const char *deb)
{
    int     cnt = 0;

    if (ar_extract(deb, SYPKG_TMP, SYPKG_CTL_FILENAME_TARGZ, &cnt) < SYPKG_OK) {
        return  (SYPKG_ERR);
    }
    if (cnt < 1) {
        if (ar_extract(deb, SYPKG_TMP, SYPKG_CTL_FILENAME_TAR, &cnt) < SYPKG_OK) {
            return  (SYPKG_ERR);
        }
    }
    if (cnt < 1) {
        SYPKG_PRINT_ERROR("sypkg can not extract control file.\n");
        return  (SYPKG_ERR);
    }

    sypkg_debinfo_clear(&debinfo);

    /* release control package */
    SYPKG_PRINT("unpackage control files...\n");
    if (access(SYPKG_CTL_FILE_PKG_TARGZ, R_OK) == 0) {
        untargz(SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_TMP, NULL);

    } else if (access(SYPKG_CTL_FILE_PKG_TAR, R_OK) == 0) {
        untar(SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_TMP, NULL);

    } else {
        SYPKG_PRINT_ERROR("sypkg can not find : %s or %s\n",
                SYPKG_CTL_FILE_PKG_TARGZ, SYPKG_CTL_FILE_PKG_TAR);
        return  (SYPKG_ERR);
    }

    /* get/print configration */
    SYPKG_PRINT("configration:\n");
    system("cat " SYPKG_TMP "/" SYPKG_CTL_FILENAME);

	return	(SYPKG_OK);
}

/*
 *  show a software message
 *  name : software name
 */
static int sypkg_show (void)
{
    static char  header[] = "       package         version        arch              contact\n"
                            "-------------------- ------------ ------------ --------------------------\n";
    char    path_buf[PATH_MAX + 1];
    DIR     *dir;
    struct dirent   *ent;
    char    *contact;

    sypkg_debinfo_clear(&debinfo);

    SYPKG_PRINT(header);

    dir = opendir(SYPKG_DIRECTORY);
    if (dir) {

        do {
            ent = readdir(dir);
            if (ent == NULL) {
                break;
            }

            snprintf(package_dir, PATH_MAX + 1, "%s/%s", SYPKG_DIRECTORY, ent->d_name);

            if (strcmp(package_dir, SYPKG_TMP) == 0) {
                continue;
            }

            if (ent->d_type == DT_UNKNOWN) {
                struct stat  sta;
                lstat(package_dir, &sta);
                if (!S_ISDIR(sta.st_mode)) {
                    continue;
                }
            } else if (ent->d_type != DT_DIR) {
                continue;
            }

            snprintf(path_buf, PATH_MAX + 1, "%s/%s", package_dir, SYPKG_CTL_FILENAME);
            if (sypkg_debinfo_analyse_file(&debinfo, path_buf)) {
                continue;
            }

            if (debinfo.maintainer) {
                contact = debinfo.maintainer;
            } else if (debinfo.author) {
                contact = debinfo.author;
            } else {
                contact = "NONE";
            }

            SYPKG_PRINT("%-20s %-12s %-12s %-26s\n",
                        debinfo.package,
                        (debinfo.version ? debinfo.version : "NONE"),
                        (debinfo.architecture ? debinfo.architecture : "NONE"),
                        contact);
        } while (1);

        closedir(dir);
    }
    SYPKG_PRINT("\n");

    sypkg_debinfo_clear(&debinfo);

    return  (SYPKG_OK);
}

#define SYPKG_HELP          "sypkg is a deb tools version : " SYPKG_VERSION "\n"	\
							"Copyright (c) 2001-2012 SylixOS Group.\n" \
                            "use this tool you can install .deb software to SylixOS/VxWorks.\n" \
                            "argments : \n" \
                            "-install           install a deb software\n"   \
                            "-uninstall         uninstall a deb software\n" \
                            "                   (install message must in database)\n" \
                            "-remove            remove a software use a list file (Danger!)\n"  \
                            "-info              print a deb package infomation\n"    \
                            "-show              show all installed software in database\n"

/*
 *  sypkg entry
 */
int main (int argc, char *argv[])
{
	int		ret;
	int		op;
#define INSTALL		0
#define UNINSTALL	1
#define REMOVE      2
#define INFO		3
#define SHOW        4


	if ((argc == 2) && (strcmp("-show", argv[1]) == 0)) {
	    sypkg_show();
	    return  (0);

	} else {
        if (argc < 3) {
            SYPKG_PRINT_ERROR("too few arguments.\n");
            SYPKG_PRINT("%s\n", SYPKG_HELP);
            return	(0);
        }

        if (strcmp("-install", argv[1]) == 0) {
            op = INSTALL;
        } else if (strcmp("-uninstall", argv[1]) == 0) {
            op = UNINSTALL;
        } else if (strcmp("-remove", argv[1]) == 0) {
            op = REMOVE;
        } else if (strcmp("-info", argv[1]) == 0) {
            op = INFO;
        } else if (strcmp("-show", argv[1]) == 0) {
            op = SHOW;
        } else {
            SYPKG_PRINT_ERROR("arguments error.\n");
            SYPKG_PRINT("%s\n", SYPKG_HELP);
            return	(SYPKG_ERR);
        }
	}

	SYPKG_PRINT("initialize sypkg work directory...\n");
	if (sypkg_workdirectory_init() < SYPKG_OK) {
		return	(SYPKG_ERR);
	}

	SYPKG_PRINT("lock sypkg work directory...\n");
	if (sypkg_workdirectory_lock(100, 5) < SYPKG_OK) {
		return	(SYPKG_ERR);
	}

	SYPKG_PRINT("remove tmp files...\n");
    sypkg_workdirectory_rm_tmp();

	switch (op) {

	case INSTALL:
		SYPKG_PRINT("install...\n");
		ret = sypkg_install(argv[2]);
		break;

	case UNINSTALL:
		SYPKG_PRINT("uninstall...\n");
		ret = sypkg_uninstall(argv[2]);
		break;

	case REMOVE:
        SYPKG_PRINT("remove...\n");
        ret = sypkg_remove(argv[2]);
        break;

	case INFO:
		SYPKG_PRINT("info...\n");
		ret = sypkg_info(argv[2]);
		break;
	}

	SYPKG_PRINT("remove tmp files...\n");
	sypkg_workdirectory_rm_tmp();

	SYPKG_PRINT("unlock sypkg work directory...\n");
	sypkg_workdirectory_unlock();

	if (ret == SYPKG_OK) {
		SYPKG_PRINT("ok.\n");
	} else {
	    SYPKG_PRINT("error!\n");
	}

	return	(ret);
}
/* end */
