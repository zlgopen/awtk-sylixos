/*
 * sylixos .deb install tools.
 *
 * sypkg mics function.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#include "sypkg.h"

/*
 *  remove all files in path (empty directory)
 *  rm_dir: remove the path directory?
 */
void remove_all_files (const char *path, int  rm_dir)
{
	char			*filename = (char *)malloc(PATH_MAX + 1);
	DIR				*dir;
	struct dirent   *ent;
	unsigned char	 type;

	if (!filename) {
	    SYPKG_PRINT_ERROR("****** no memory *****.\n");
		return;
	}

	dir = opendir(path);
	if (!dir) {
	    free(filename);
		return;
	}

	ent = readdir(dir);

	while (ent) {
		snprintf(filename, PATH_MAX + 1, "%s/%s", path, ent->d_name);
		type = ent->d_type;

		ent = readdir(dir);	/* next */

		if (type == DT_UNKNOWN) {
			struct stat  sta;
			lstat(filename, &sta);
			if (S_ISDIR(sta.st_mode)) {
				remove_all_files(filename, 1);
			} else {
				unlink(filename);
			}

		} else {
			if (type == DT_DIR) {
				remove_all_files(filename, 1);
			} else {
				unlink(filename);
			}
		}
	}

	free(filename);

	closedir(dir);

	if (rm_dir) {
		unlink(path);
	}
}

/*
 *  remove all files in list,
 */
struct file_list {
    struct file_list *next;
    char    name[1];
};

void remove_list_files (const char *list)
{
    struct file_list *node;
    struct file_list *header = NULL;

    FILE    *fp;
    char    namebuf[PATH_MAX + 1];
    char    *name;

    fp = fopen(list, "r");
    if (fp == NULL) {
        return;
    }

    name = fgets(namebuf, sizeof(namebuf), fp);
    while (name) {
        int   len = strlen(name);

        if (len < 1) {
            goto    __next;
        }
        if (name[len - 1] == '\n') {
            name[len - 1] = '\0';
            len--;
        }
        if (len < 1) {
            goto    __next;
        }

        node = (struct file_list *)malloc(sizeof(struct file_list) + len);
        if (!node) {
            SYPKG_PRINT_ERROR("****** no memory *****.\n");
            break;
        }
        strcpy(node->name, name);

        node->next = header;
        header = node;

__next:
        name = fgets(namebuf, sizeof(namebuf), fp);
    }

    fclose(fp);

    while (header) {
        node = header;
        header = node->next;

        SYPKG_PRINT("remove %s ...\n", node->name);
        unlink(node->name);
        free(node);
    }
}

/*
 *  file copy
 */
int  file_copy (const char *dst, const char *src)
{
#define CP_BUF_SIZE     512
    int  fd_dst;
    int  fd_src;
    char buf[CP_BUF_SIZE];

    struct stat  st;
    int  i, times, lefts;

    fd_dst = creat(dst, SYPKG_DEFAULT_FILE_PERM);
    if (fd_dst < 0) {
        SYPKG_PRINT_ERROR("sypkg can not create %s file.\n", dst);
        return  (SYPKG_ERR);
    }

    fd_src  = open(src, O_RDONLY);
    if (fd_src < 0) {
        close(fd_dst);
        unlink(dst);
        SYPKG_PRINT_ERROR("sypkg can not open %s file.\n", src);
        return  (SYPKG_ERR);
    }

    if (fstat(fd_src, &st) < 0) {
        close(fd_src);
        close(fd_dst);
        unlink(dst);
        SYPKG_PRINT_ERROR("sypkg can not get %s stat.\n", src);
        return  (SYPKG_ERR);
    }

    times = st.st_size / CP_BUF_SIZE;
    lefts = st.st_size % CP_BUF_SIZE;

    for (i = 0; i < times; i++) {
        if (read(fd_src, buf, CP_BUF_SIZE) != CP_BUF_SIZE) {
            return  (SYPKG_ERR);
        }
        if (write(fd_dst, buf, CP_BUF_SIZE) != CP_BUF_SIZE) {
            return  (SYPKG_ERR);
        }
    }

    if (lefts) {
        if (read(fd_src, buf, lefts) != lefts) {
            return  (SYPKG_ERR);
        }
        if (write(fd_dst, buf, lefts) != lefts) {
            return  (SYPKG_ERR);
        }
    }

    close(fd_src);
    close(fd_dst);

    return  (SYPKG_OK);
}
/* end */
