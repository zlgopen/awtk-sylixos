/*
 * sylixos .deb install tools.
 *
 * ar package operate.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#include "sypkg.h"

/*
 *  copy data from ar to unpackage file
 */
static int  ar_data_copy (int  fd_src, int  fd_dst, int  size)
{
#define AR_COPY_BUF_SIZE    1024
    char    buf[AR_COPY_BUF_SIZE];
    int     times = size / AR_COPY_BUF_SIZE;
    int     lefts = size % AR_COPY_BUF_SIZE;

    int     i;

    for (i = 0; i < times; i++) {
        if (read(fd_src, buf, AR_COPY_BUF_SIZE) != AR_COPY_BUF_SIZE) {
            return  (SYPKG_ERR);
        }
        if (write(fd_dst, buf, AR_COPY_BUF_SIZE) != AR_COPY_BUF_SIZE) {
            return  (SYPKG_ERR);
        }
    }

    if (lefts) {
        if (read(fd_src, buf, lefts) != lefts) {
            return  (SYPKG_ERR);
        }
        if (write(fd_dst, buf, lefts) != lefts) {
            return  (SYPKG_ERR);
        }
    }

    return  (SYPKG_OK);
}

/*
 *  extract ar file
 *  file: ar file
 *  dest_directory:extract destination
 *  onlyfile: if onlyfile not NULL, only extract this file.
 *  cnt:restor counter of file has been extract.
 */
int ar_extract (const char *file, const char *dest_directory, const char *onlyfile, int *cnt)
{
    int     fd_ar;
    int     fd_dest;
    char    dest_file[PATH_MAX + 1];
    char    ar_file_header[8];
    struct ar_hdr ar_header;

    char    *tmp;
    int     size;

    char    ex_name[17];
    char    ex_size[11];

    if (cnt) {
        *cnt = 0;
    }

    fd_ar = open(file, O_RDONLY);
    if (fd_ar < 0) {
        SYPKG_PRINT_ERROR("sypkg can not open : %s\n", file);
        return  (SYPKG_ERR);
    }

    if (read(fd_ar, ar_file_header, 8) != 8) {
        SYPKG_PRINT_ERROR("sypkg file %s header read error!\n", file);
        goto    __file_format_error;
    }

    if (memcmp(ar_file_header, ARMAG, SARMAG)) {
        SYPKG_PRINT_ERROR("sypkg file %s file header format error!\n", file);
        goto    __file_format_error;
    }

    while (1) {
        if (read(fd_ar, (void *)&ar_header, sizeof(ar_header)) != sizeof(ar_header)) {
            break;
        }
        if (memcmp(ar_header.ar_fmag, ARFMAG, 2)) {
            SYPKG_PRINT_ERROR("sypkg file %s ARFMAG format error!\n"
                              "ar_fmag[0] : %x ar_fmag[1] : %x\n",
                              file,
                              ar_header.ar_fmag[0],
                              ar_header.ar_fmag[1]);
            goto    __file_format_error;
        }

        strlcpy(ex_name, ar_header.ar_name, 17);
        tmp = strchr(ex_name, '/');
        if (tmp && ((tmp - ex_name) < 16)) {
            *tmp = '\0';
        } else {
            tmp = strchr(ex_name, ' ');
            if (tmp && ((tmp - ex_name) < 16)) {
                *tmp = '\0';
            } else {
                goto    __file_format_error;
            }
        }
        if (strlen(ex_name) == 0) {
            SYPKG_PRINT_ERROR("sypkg file %s can not support long filename!\n", file);
            goto    __file_format_error;
        }

        strlcpy(ex_size, ar_header.ar_size, 11);
        size = atoi(ex_size);

        if ((onlyfile == NULL) || (strcmp(onlyfile, ex_name) == 0)) {

            SYPKG_PRINT("unpackage %s->%s size : %d ...\n", file, ex_name, size);

            snprintf(dest_file, PATH_MAX + 1, "%s/%s", dest_directory, ex_name);
            fd_dest = open(dest_file, (O_CREAT | O_WRONLY | O_TRUNC), SYPKG_DEFAULT_FILE_PERM);
            if (fd_dest < 0) {
                goto    __file_create_error;
            }

            if (size > 0) {
                if (ar_data_copy(fd_ar, fd_dest, size)) {
                    goto    __file_write_error;
                }
            }

            if (size % 2) {
                char  dump;
                read(fd_ar, &dump, 1);
            }

            close(fd_dest);

            if (cnt) {
                (*cnt)++;
            }

        } else {
            if (size % 2) {
                lseek(fd_ar, size + 1, SEEK_CUR);
            } else {
                lseek(fd_ar, size, SEEK_CUR);
            }
        }
    }

    close(fd_ar);
	return	(SYPKG_OK);

__file_format_error:
    close(fd_ar);
    return  (SYPKG_ERR);

__file_create_error:
    close(fd_ar);
    SYPKG_PRINT_ERROR("sypkg file %s create error!\n", dest_file);
    return  (SYPKG_ERR);

__file_write_error:
    close(fd_dest);
    close(fd_ar);
    SYPKG_PRINT_ERROR("sypkg file %s write error!\n", dest_file);
    return  (SYPKG_ERR);
}

/* end */
