/*
 * sylixos .deb install tools.
 *
 * tar package operate.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#include "sypkg.h"

#ifndef min
#define min(a, b)   ((a) > (b) ? (b) : (a))
#endif

struct tar_header {
    char    name[100];
    char    mode[8];
    char    uid[8];
    char    gid[8];
    char    size[12];
    char    mtime[12];
    char    chksum[8];
    char    typeflag;
    char    linkname[100];
    char    magic[6];
    char    version[2];
    char    uname[32];
    char    gname[32];
    char    devmajor[8];
    char    devminor[8];
    char    prefix[155];
    char    padding[12];
};

/*
 *  oct ascii to unsigned long
 */
static unsigned long octal2ulong (const char *octascii, size_t len)
{
   size_t        i;
   unsigned long num;

   num = 0;

   for (i = 0; i < len; i++) {
      if ((octascii[i] < '0') || (octascii[i] > '9')) {
         continue;
      }
      num  = num * 8 + ((unsigned long)(octascii[i] - '0'));
   }

   return   (num);
}

/*
 *  tar_header_checksum
 */
static int tar_header_checksum (const char *buf)
{
   int  i, sum;

   sum = 0;
   for (i = 0; i < 512; i++) {
      if ((i >= 148) && (i < 156)) {
         sum += 0xff & ' ';
      } else {
         sum += 0xff & buf[i];
      }
   }

   return   (sum);
}

/*
 *  untar a .tar file , if dest_dir == NULL then untar current dir.
 */
int untar (const char *tar, const char *dest_dir, void (*cb)(const char *name))
{
    int     fd_tar = open(tar, O_RDONLY);

    char    *buf;
    ssize_t  n;
    char     fname[100];
    char     linkname[100];
    int            sum;
    int            hdr_chksum;
    int            retval;
    unsigned long  i;
    unsigned long  nblocks;
    unsigned long  size;
    unsigned char  linkflag;

    if (fd_tar < 0) {
        SYPKG_PRINT_ERROR("sypkg can not open : %s\n", tar);
        return  (SYPKG_ERR);
    }

    buf = (char *)malloc(512);
    if (buf == NULL) {
        close(fd_tar);
        SYPKG_PRINT_ERROR("****** no memory *****.\n");
        return  (SYPKG_ERR);
    }

    retval = SYPKG_OK;

    while (1) {
        char    out_filename[PATH_MAX + 1];
        mode_t  mode;

        /* Read the header */
        /* If the header read fails, we just consider it the end
           of the tarfile. */
        if ((n = read(fd_tar, buf, 512)) != 512) {
            break;
        }

        if (strncmp(&buf[257], TMAGIC, 5)) {
            break;
        }

        strlcpy(fname, buf, 100);

        linkflag   = buf[156];
        size       = octal2ulong(&buf[124], 12);

        /*
         * Compute the TAR checksum and check with the value in
         * the archive.  The checksum is computed over the entire
         * header, but the checksum field is substituted with blanks.
         */
        hdr_chksum = octal2ulong(&buf[148], 8);
        sum = tar_header_checksum(buf);

        if (sum != hdr_chksum) {
            SYPKG_PRINT_ERROR("sypkg file : %s chksum error.\n", tar);
            retval = SYPKG_ERR;
            break;
        }

        /*
         * get mode
         */
        mode = octal2ulong(&buf[100], 8);

        /*
         * combin filename
         */
        if (dest_dir) {
            snprintf(out_filename, PATH_MAX + 1, "%s/%s", dest_dir, fname);
        } else {
            strlcpy(out_filename, fname, PATH_MAX + 1);
        }

        /*
         * We've decoded the header, now figure out what it contains and
         * do something with it.
         */
        if (linkflag == SYMTYPE) {
            SYPKG_PRINT("unpackage %s <LNK> ...\n", out_filename);

            strlcpy(linkname, &buf[157], 100);
            if (symlink(linkname, out_filename) == 0) {
                if (cb) {
                    cb(out_filename);
                }
            }
        } else if (linkflag == REGTYPE) {
            int     out_fd;

            SYPKG_PRINT("unpackage %s size : %ld ...\n", out_filename, size);

            /*
             * Read out the data.  There are nblocks of data where nblocks
             * is the size rounded to the nearest 512-byte boundary.
             */
            nblocks = (((size) + 511) & ~511) / 512;

            if ((out_fd = creat(out_filename, mode)) < 0) {
                lseek(fd_tar, nblocks * 512, SEEK_CUR);

            } else {
                for (i = 0; i < nblocks; i++) {
                    n = read(fd_tar, buf, 512);
                    n = min(n, size - (i * 512));
                    write(out_fd, buf, n);
                }
                close(out_fd);
            }

            if (cb) {
                cb(out_filename);
            }

        } else if (linkflag == DIRTYPE) {
            SYPKG_PRINT("unpackage %s <DIR> ...\n", out_filename);

            if (mkdir(out_filename, mode) == 0) {
                if (cb) {
                    cb(out_filename);
                }
            }
        }
    }
    free(buf);
    close(fd_tar);

    return  (SYPKG_OK);
}

/*
 *  untar a .tar.gz file , if dest_dir == NULL then untar current dir.
 */
int untargz (const char *tar, const char *dest_dir, void (*cb)(const char *name))
{
    int     fd_tar = open(tar, O_RDONLY);
    gzFile  gzTar;

    char    *buf;
    ssize_t  n;
    char     fname[100];
    char     linkname[100];
    int            sum;
    int            hdr_chksum;
    int            retval;
    unsigned long  i;
    unsigned long  nblocks;
    unsigned long  size;
    unsigned char  linkflag;

    if (fd_tar < 0) {
        SYPKG_PRINT_ERROR("sypkg can not open : %s\n", tar);
        return  (SYPKG_ERR);
    }

    buf = (char *)malloc(512);
    if (buf == NULL) {
        close(fd_tar);
        SYPKG_PRINT_ERROR("****** no memory *****.\n");
        return  (SYPKG_ERR);
    }

    gzTar = gzdopen(fd_tar, "rb");
    if (!gzTar) {
        free(buf);
        close(fd_tar);
        SYPKG_PRINT_ERROR("sypkg zlib can not open : %s\n", tar);
        return  (SYPKG_ERR);
    }

    retval = SYPKG_OK;

    while (1) {
        char    out_filename[PATH_MAX + 1];
        mode_t  mode;

        /* Read the header */
        /* If the header read fails, we just consider it the end
           of the tarfile. */
        if ((n = gzread(gzTar, buf, 512)) != 512) {
            break;
        }

        if (strncmp(&buf[257], TMAGIC, 5)) {
            break;
        }

        strlcpy(fname, buf, 100);

        linkflag   = buf[156];
        size       = octal2ulong(&buf[124], 12);

        /*
         * Compute the TAR checksum and check with the value in
         * the archive.  The checksum is computed over the entire
         * header, but the checksum field is substituted with blanks.
         */
        hdr_chksum = octal2ulong(&buf[148], 8);
        sum = tar_header_checksum(buf);

        if (sum != hdr_chksum) {
            SYPKG_PRINT_ERROR("sypkg file : %s chksum error.\n", tar);
            retval = SYPKG_ERR;
            break;
        }

        /*
         * get mode
         */
        mode = octal2ulong(&buf[100], 8);

        /*
         * combin filename
         */
        if (dest_dir) {
            snprintf(out_filename, PATH_MAX + 1, "%s/%s", dest_dir, fname);
        } else {
            strlcpy(out_filename, fname, PATH_MAX + 1);
        }

        /*
         * We've decoded the header, now figure out what it contains and
         * do something with it.
         */
        if (linkflag == SYMTYPE) {
            SYPKG_PRINT("unpackage %s <LNK> ...\n", out_filename);

            strlcpy(linkname, &buf[157], 100);
            if (symlink(linkname, out_filename) == 0) {
                if (cb) {
                    cb(out_filename);
                }
            }
        } else if (linkflag == REGTYPE) {
            int     out_fd;

            SYPKG_PRINT("unpackage %s size : %ld ...\n", out_filename, size);

            /*
             * Read out the data.  There are nblocks of data where nblocks
             * is the size rounded to the nearest 512-byte boundary.
             */
            nblocks = (((size) + 511) & ~511) / 512;

            if ((out_fd = creat(out_filename, mode)) < 0) {
                gzseek(gzTar, (nblocks * 512), SEEK_CUR);

            } else {
                for (i = 0; i < nblocks; i++) {
                    n = gzread(gzTar, buf, 512);
                    n = min(n, size - (i * 512));
                    write(out_fd, buf, n);
                }
                close(out_fd);
            }

            if (cb) {
                cb(out_filename);
            }

        } else if (linkflag == DIRTYPE) {
            SYPKG_PRINT("unpackage %s <DIR> ...\n", out_filename);

            if (mkdir(out_filename, mode) == 0) {
                if (cb) {
                    cb(out_filename);
                }
            }
        }
    }
    free(buf);
    gzclose(gzTar);

	return	(SYPKG_OK);
}

/* end */
