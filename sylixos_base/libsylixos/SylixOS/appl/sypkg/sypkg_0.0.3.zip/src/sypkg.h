/*
 * sylixos .deb install tools.
 *
 * sypkg tool header.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#ifndef __SYPKG_H
#define __SYPKG_H

#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ar.h>
#include <tar.h>
#include <zlib.h>

/* sypkg version */
#define SYPKG_VERSION		"0.0.3"
#define SYPKG_REVISION		"0"

/* sypkg work directory */
#define SYPKG_DIRECTORY		"/var/sypkg"
#define SYPKG_TMP			SYPKG_DIRECTORY "/tmp"
#define SYPKG_LOCK_FILE		SYPKG_DIRECTORY "/lock"
#define SYPKG_DB_FILE		SYPKG_DIRECTORY "/info.db"

/* deb package file name */
#define SYPKG_CTL_FILENAME_TARGZ    "control.tar.gz"
#define SYPKG_CTL_FILENAME_TAR      "control.tar"
#define SYPKG_CTL_FILENAME          "control"

#define SYPKG_RMLIST_FILENAME       "rm.list"

#define SYPKG_CTL_FILE_PKG_TARGZ	SYPKG_TMP "/control.tar.gz"
#define SYPKG_CTL_FILE_PKG_TAR		SYPKG_TMP "/control.tar"

#define SYPKG_DATA_FILE_PKG_TARGZ	SYPKG_TMP "/data.tar.gz"
#define SYPKG_DATA_FILE_PKG_TAR		SYPKG_TMP "/data.tar"

/* Architecture detect */
#ifdef SYLIXOS
#define SYPKG_ARCH	"sylixos-arm"
#elif defined(LINUX)
#define SYPKG_ARCH  "linux-arm"
#elif defined(VXWORKS)
#define SYPKG_ARCH  "vxworks-arm"
#endif

/* script file define */
#define SYPKG_PREINST   "preinst"
#define SYPKG_POSTINST  "postinst"

#define SYPKG_PRERM     "prerm"
#define SYPKG_POSTRM    "postrm"

/* file mode */
#ifdef DEFAULT_FILE_PERM
#define SYPKG_DEFAULT_FILE_PERM		DEFAULT_FILE_PERM
#else
#define	SYPKG_DEFAULT_FILE_PERM		0000644
#endif

#ifdef DEFAULT_DIR_PERM
#define SYPKG_DEFAULT_DIR_PERM		DEFAULT_DIR_PERM
#else
#define SYPKG_DEFAULT_DIR_PERM		0000754
#endif

/* function return value */
#define SYPKG_OK			0
#define SYPKG_ERR			(-1)

/* message and print routine */
#define SYPKG_PRINT			printf
#define SYPKG_PRINT_ERROR	printf

/* internal sturct */
struct deb_depend {
     struct deb_depend *next;
     int    type;
#define SYPKG_DEPENDS   0
#define SYPKG_PRE_PENDS 1
#define SYPKG_CONFLICTS 2
#define SYPKG_REPLACES  3
#define SYPKG_PROVIDES  4
     char   name[1];
};

struct deb_info {
    char    *package;
    char    *priority;
    char    *name;
    char    *version;
    char    *installed_size;
    char    *section;
    char    *architecture;
    char    *author;
    char    *maintainer;
    char    *description;
    char    *homepage;
    struct deb_depend  *depend_header;
};

/* internal function (not use) */
int ar_extract(const char *file, const char *dest_directory, const char *onlyfile, int *cnt);
int untar(const char *tar, const char *dest_dir, void (*cb)(const char *name));
int untargz(const char *tar, const char *dest_dir, void (*cb)(const char *name));

int  file_copy(const char *dst, const char *src);
void remove_all_files(const char *path, int  rm_dir);
void remove_list_files(const char *list);

void sypkg_debinfo_analyse_mem(struct deb_info *info, char *buf);
int  sypkg_debinfo_analyse_file(struct deb_info *info, const char *control);
void sypkg_debinfo_clear(struct deb_info *info);

#endif /* __SYPKG_H */
/* end */
