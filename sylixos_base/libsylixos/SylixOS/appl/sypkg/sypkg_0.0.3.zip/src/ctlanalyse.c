/*
 * sylixos .deb install tools.
 *
 * sypkg tool.
 */
/*
 * Copyright (c) 2001-2012 SylixOS Group.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * Author: Han.hui <sylixos@gmail.com>
 *
 */

#include "sypkg.h"

/*
 *  clear deb info all message.
 */
void sypkg_debinfo_clear (struct deb_info *info)
{
	if (info->package) {
		free(info->package);
		info->package = NULL;
	}
	if (info->priority) {
		free(info->priority);
		info->priority = NULL;
	}
	if (info->name) {
		free(info->name);
		info->name = NULL;
	}
	if (info->version) {
		free(info->version);
		info->version = NULL;
	}
	if (info->installed_size) {
		free(info->installed_size);
		info->installed_size = NULL;
	}
	if (info->section) {
		free(info->section);
		info->section = NULL;
	}
	if (info->architecture) {
		free(info->architecture);
		info->architecture = NULL;
	}
	if (info->author) {
		free(info->author);
		info->author = NULL;
	}
	if (info->maintainer) {
		free(info->maintainer);
		info->maintainer = NULL;
	}
	if (info->description) {
		free(info->description);
		info->description = NULL;
	}
	if (info->homepage) {
		free(info->homepage);
		info->homepage = NULL;
	}

	while (info->depend_header) {
		struct deb_depend  *tmp = info->depend_header;
		info->depend_header = tmp->next;
		free(tmp);
	}
}

/*
 *  add package message into deb info.
 */
static void sypkg_debinfo_add_package (struct deb_info *info, const char *package)
{
	if (info->package) {
		free(info->package);
	}
	info->package = strdup(package);
}

/*
 *  add priority message into deb info.
 */
static void sypkg_debinfo_add_priority (struct deb_info *info, const char *priority)
{
	if (info->priority) {
		free(info->priority);
	}
	info->priority = strdup(priority);
}

/*
 *  add name message into deb info.
 */
static void sypkg_debinfo_add_name (struct deb_info *info, const char *name)
{
	if (info->name) {
		free(info->name);
	}
	info->name = strdup(name);
}

/*
 *  add version message into deb info.
 */
static void sypkg_debinfo_add_version (struct deb_info *info, const char *version)
{
	if (info->version) {
		free(info->version);
	}
	info->version = strdup(version);
}

/*
 *  add installed_size message into deb info.
 */
static void sypkg_debinfo_add_installed_size (struct deb_info *info, const char *installed_size)
{
	if (info->installed_size) {
		free(info->installed_size);
	}
	info->installed_size = strdup(installed_size);
}

/*
 *  add section message into deb info.
 */
static void sypkg_debinfo_add_section (struct deb_info *info, const char *section)
{
	if (info->section) {
		free(info->section);
	}
	info->section = strdup(section);
}

/*
 *  add pre_depends message into deb info.
 */
static void sypkg_debinfo_add_pre_depends (struct deb_info *info, const char *pre_depends)
{
}

/*
 *  add depends message into deb info.
 */
static void sypkg_debinfo_add_depends (struct deb_info *info, const char *depends)
{
}

/*
 *  add conflicts message into deb info.
 */
static void sypkg_debinfo_add_conflicts (struct deb_info *info, const char *conflicts)
{
}

/*
 *  add replaces message into deb info.
 */
static void sypkg_debinfo_add_replaces (struct deb_info *info, const char *replaces)
{
}

/*
 *  add provides message into deb info.
 */
static void sypkg_debinfo_add_provides (struct deb_info *info, const char *provides)
{
}

/*
 *  add architecture message into deb info.
 */
static void sypkg_debinfo_add_architecture (struct deb_info *info, const char *architecture)
{
    if (info->architecture) {
        free(info->architecture);
    }
    info->architecture = strdup(architecture);
}

/*
 *  add author message into deb info.
 */
static void sypkg_debinfo_add_author (struct deb_info *info, const char *author)
{
    if (info->author) {
        free(info->author);
    }
    info->author = strdup(author);
}

/*
 *  add maintainer message into deb info.
 */
static void sypkg_debinfo_add_maintainer (struct deb_info *info, const char *maintainer)
{
    if (info->maintainer) {
        free(info->maintainer);
    }
    info->maintainer = strdup(maintainer);
}

/*
 *  add description message into deb info.
 */
static void sypkg_debinfo_add_description (struct deb_info *info, const char *description)
{
}

/*
 *  add homepage message into deb info.
 */
static void sypkg_debinfo_add_homepage (struct deb_info *info, const char *homepage)
{
}

void sypkg_debinfo_analyse_mem (struct deb_info *info, char *buf)
{
    char    *delim="\r\n:, ";
    char    *delim_next_line="\r\n ";
    char    *delim_next_comma=", ";
    char    *last;
    char    *ptok;

    ptok = strtok_r(buf, delim, &last);
    while (ptok) {
        if (strcmp(ptok, "Package") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_package(info, ptok);
            }

        } else if (strcmp(ptok, "Priority") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_priority(info, ptok);
            }

        } else if (strcmp(ptok, "Name") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_name(info, ptok);
            }

        } else if (strcmp(ptok, "Version") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_version(info, ptok);
            }

        } else if (strcmp(ptok, "Installed-Size") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_installed_size(info, ptok);
            }

        } else if (strcmp(ptok, "Section") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_section(info, ptok);
            }

        } else if (strcmp(ptok, "Architecture") == 0) {
            ptok = strtok_r(NULL, delim_next_line, &last);
            if (ptok) {
                sypkg_debinfo_add_architecture(info, ptok);
            }

        } else if (strcmp(ptok, "Author") == 0) {
            ptok = strtok_r(NULL, "\n", &last);
            if (ptok) {
                if (*ptok == ' ') {
                    ptok++;
                }
                sypkg_debinfo_add_author(info, ptok);
            }

        } else if (strcmp(ptok, "Maintainer") == 0) {
            ptok = strtok_r(NULL, "\n", &last);
            if (ptok) {
                if (*ptok == ' ') {
                    ptok++;
                }
                sypkg_debinfo_add_maintainer(info, ptok);
            }
        }


        ptok = strtok_r(NULL, delim, &last);
    }
}

/*
 *  full deb info with control file
 */
int sypkg_debinfo_analyse_file (struct deb_info *info, const char *control)
{
	int		fd = open(control, O_RDONLY);
	char	*buf;
	struct stat   state;

	if (fstat(fd, &state) < 0) {
		close(fd);
		SYPKG_PRINT_ERROR("sypkg can not stat : %s\n", control);
		return  (SYPKG_ERR);
	}

	buf = (char *)malloc(state.st_size);
	if (buf == NULL) {
		close(fd);
		SYPKG_PRINT_ERROR("****** no memory *****.\n");
		return  (SYPKG_ERR);
	}

	if (read(fd, buf, state.st_size) != state.st_size) {
		close(fd);
		SYPKG_PRINT_ERROR("sypkg can not read : %s\n", control);
		return  (SYPKG_ERR);
	}

	close(fd);

	sypkg_debinfo_analyse_mem(info, buf);

	free(buf);

	return	(SYPKG_OK);
}

/* end */
