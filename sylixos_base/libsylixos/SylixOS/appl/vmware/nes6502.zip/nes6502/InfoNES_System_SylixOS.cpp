/*********************************************************************************************************
**
**                                    �й�������Դ��֯
**
**                                   Ƕ��ʽʵʱ����ϵͳ
**
**                                SylixOS(TM)  LW : long wing
**
**                               Copyright All Rights Reserved
**
**--------------�ļ���Ϣ--------------------------------------------------------------------------------
**
** ��   ��   ��: InfoNES_System_SylixOS.cpp
**
** ��   ��   ��: Han.Hui (����)
**
** �ļ���������: 2010 �� 01 �� 16 ��
**
** ��        ��: ����ϵͳ InfoNES ��ֲ�ļ�. (ͼ�δ����ǳ��� 16bit, ��������ʹ��)
                 �����ֲĿǰ������һ�������İ汾, ��ʹ���� /dev/fb0 ͼ���豸, ����û��һֻ�����ͼ�¼�ļ�.
                 ����Ȥ�����ѿ����Լ�����.
*********************************************************************************************************/
#include "SylixOS.h"
#include "stdlib.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "./InfoNES/InfoNES.h"
#include "./InfoNES/InfoNES_System.h"
#include "./InfoNES/InfoNES_pAPU.h"
#include "./InfoNES/InfoNES_Mapper.h"
#include "./InfoNES/K6502.h"

/*===================================================================*/
/*           var                                                     */
/*===================================================================*/
static BOOL     _G_bNesRunning    = FALSE;
static PCHAR    _G_pcFrameBuffer  = NULL;
static ULONG    _G_ulBytesPerLine = 0;

static DWORD    _G_dwPad1;
static DWORD    _G_dwPad2;
static DWORD    _G_dwSystem;
static INT      _G_iPadTty = -1;
static INT      _G_i2XDisp = 0;

// 555 to 565
#define __GMEMDEV_PIX_TO_PIX(nespix)        (((((nespix) & 0xFFE0) << 1)) | ((nespix) & 0x001F))

// Palette data 555 0RRRRRGGGGGBBBBBB
WORD NesPalette[ 64 ] =
{
  0x39ce, 0x1071, 0x0015, 0x2013, 0x440e, 0x5402, 0x5000, 0x3c20,
  0x20a0, 0x0100, 0x0140, 0x00e2, 0x0ceb, 0x0000, 0x0000, 0x0000,
  0x5ef7, 0x01dd, 0x10fd, 0x401e, 0x5c17, 0x700b, 0x6ca0, 0x6521,
  0x45c0, 0x0240, 0x02a0, 0x0247, 0x0211, 0x0000, 0x0000, 0x0000,
  0x7fff, 0x1eff, 0x2e5f, 0x223f, 0x79ff, 0x7dd6, 0x7dcc, 0x7e67,
  0x7ae7, 0x4342, 0x2769, 0x2ff3, 0x03bb, 0x0000, 0x0000, 0x0000,
  0x7fff, 0x579f, 0x635f, 0x6b3f, 0x7f1f, 0x7f1b, 0x7ef6, 0x7f75,
  0x7f94, 0x73f4, 0x57d7, 0x5bf9, 0x4ffe, 0x0000, 0x0000, 0x0000
};

/*-------------------------------------------------------------------*/
/*  ROM image file information                                       */
/*-------------------------------------------------------------------*/

char szRomName[ NAME_MAX + 1 ];
char szSaveName[ NAME_MAX + 1 ];
int  nSRAM_SaveFlag;

char szLoadRamBuffer[ SRAM_SIZE ];
char szSaveRamBuffer[ SRAM_SIZE ];

int LoadSRAM();
int SaveSRAM();

/*===================================================================*/
/*                                                                   */
/*           InfoNES_ReleaseRom() : Release a memory for ROM         */
/*                                                                   */
/*===================================================================*/
void InfoNES_ReleaseRom()
{
/*
 *  Release a memory for ROM
 *
 */

  if ( ROM )
  {
    free( ROM );
    ROM = NULL;
  }

  if ( VROM )
  {
    free( VROM );
    VROM = NULL;
  }
}
/*===================================================================*/
/*                                                                   */
/*             InfoNES_MemorySet() : Get a joypad state              */
/*                                                                   */
/*===================================================================*/
void *InfoNES_MemorySet( void *dest, int c, int count )
{
/*
 *  memset
 *
 *  Parameters
 *    void *dest                       (Write)
 *      Points to the starting address of the block of memory to fill
 *
 *    int c                            (Read)
 *      Specifies the byte value with which to fill the memory block
 *
 *    int count                        (Read)
 *      Specifies the size, in bytes, of the block of memory to fill
 *
 *  Return values
 *    Pointer of destination
 */

  memset(dest, c, count);
  return dest;
}
/*===================================================================*/
/*                                                                   */
/*               InfoNES_ReadRom() : Read ROM image file             */
/*                                                                   */
/*===================================================================*/
int InfoNES_ReadRom( const char *pszFileName )
{
/*
 *  Read ROM image file
 *
 *  Parameters
 *    const char *pszFileName          (Read)
 *
 *  Return values
 *     0 : Normally
 *    -1 : Error
 */

  FILE *fp;

  /* Open ROM file */
  fp = fopen( pszFileName, "rb" );
  if ( fp == NULL )
    return -1;

  /* Read ROM Header */
  fread( &NesHeader, sizeof NesHeader, 1, fp );
  if ( memcmp( NesHeader.byID, "NES\x1a", 4 ) != 0 )
  {
    /* not .nes file */
    fclose( fp );
    return -1;
  }

  /* Clear SRAM */
  memset( SRAM, 0, SRAM_SIZE );

  /* If trainer presents Read Triner at 0x7000-0x71ff */
  if ( NesHeader.byInfo1 & 4 )
  {
    fread( &SRAM[ 0x1000 ], 512, 1, fp );
  }

  /* Allocate Memory for ROM Image */
  ROM = (BYTE *)malloc( NesHeader.byRomSize * 0x4000 );

  /* Read ROM Image */
  fread( ROM, 0x4000, NesHeader.byRomSize, fp );

  if ( NesHeader.byVRomSize > 0 )
  {
    /* Allocate Memory for VROM Image */
    VROM = (BYTE *)malloc( NesHeader.byVRomSize * 0x2000 );

    /* Read VROM Image */
    fread( VROM, 0x2000, NesHeader.byVRomSize, fp );
  }

  /* File close */
  fclose( fp );

  /* Successful */
  return 0;
}
/*===================================================================*/
/*                                                                   */
/*      InfoNES_LoadFrame() :                                        */
/*           Transfer the contents of work frame on the screen       */
/*                                                                   */
/*===================================================================*/
void InfoNES_LoadFrame()
{
/*
 *  Transfer the contents of work frame on the screen
 *
 */
 static int     times = 0;
 
 int   i;
 int   j;
 
 WORD *pwFrom = WorkFrame;
 WORD *pwTo   = (WORD *)_G_pcFrameBuffer;
 
 if (pwTo == NULL) {
    return;
 }
 
 if (times >= 1) {
    times = 0;
 } else {
    times++;
    return;
 }
 
 if (_G_i2XDisp) {
    /*
     *  ������С
     */
     for (i = 0; i < NES_DISP_HEIGHT; i++) {
        
        WORD *pwFromTemp = pwFrom;
        for (j = 0; j < NES_DISP_WIDTH; j++) {
          register WORD  tmp = __GMEMDEV_PIX_TO_PIX(*pwFrom);
          *pwTo++ = tmp;
          *pwTo++ = tmp;
          pwFrom++;
        }
        pwTo += (_G_ulBytesPerLine / 2) - (j * 2);
        
        pwFrom = pwFromTemp;
        for (j = 0; j < NES_DISP_WIDTH; j++) {
          register WORD  tmp = __GMEMDEV_PIX_TO_PIX(*pwFrom);
          *pwTo++ = tmp;
          *pwTo++ = tmp;
          pwFrom++;
        }
        pwTo += (_G_ulBytesPerLine / 2) - (j * 2);
     }
  } else {
     /*
      *  ԭʼ��С
      */
     for (i = 0; i < NES_DISP_HEIGHT; i++) {
       for (j = 0; j < NES_DISP_WIDTH; j++) {
          *pwTo++ = __GMEMDEV_PIX_TO_PIX(*pwFrom);
          pwFrom++;
       }
       pwTo += (_G_ulBytesPerLine / 2) - j;
     }
  }
}

/*===================================================================*/
/*                                                                   */
/*             InfoNES_PadState() : Get a joypad state               */
/*                                                                   */
/*===================================================================*/
void InfoNES_PadState( DWORD *pdwPad1, DWORD *pdwPad2, DWORD *pdwSystem )
{
/*
 *  Get a joypad state
 *
 *  Parameters
 *    DWORD *pdwPad1                   (Write)
 *      Joypad 1 State
 *
 *    DWORD *pdwPad2                   (Write)
 *      Joypad 2 State
 *
 *    DWORD *pdwSystem                 (Write)
 *      Input for InfoNES
 *
 */
 
 static int      times = 0;
 
        int      i;
        int      bytes = 0;
        ssize_t  nread = 0;
        char     buffer[64];
 
 *pdwPad1   = _G_dwPad1;
 *pdwPad2   = _G_dwPad2;
 *pdwSystem = _G_dwSystem;
 
 if (_G_iPadTty >= 0) {
    if (ioctl(_G_iPadTty, FIONREAD, &bytes) == 0) {
      if (bytes > 0) {
        nread = read(_G_iPadTty, buffer, (bytes > 64) ? 64 : bytes);
      }
    }
  }

  if (nread) {
      times = 0;
      for (i = 0; i < nread; i++) {
        switch (buffer[i]) {

        case 'x':   /* B */
            *pdwPad1 |= (1 << 0);
            break;
            
        case 'z':   /* A */
            *pdwPad1 |= (1 << 1);
            break;
            
        case 'a':   /* select */
            *pdwPad1 |= (1 << 2);
            break;
            
        case 's':   /* start */
            *pdwPad1 |= (1 << 3);
            break;
            
        case 'u':   /* up  */
            *pdwPad1 |= (1 << 4);
            break;
            
        case 'j':   /* down */
            *pdwPad1 |= (1 << 5);
            break;
            
        case 'h':   /* left */
            *pdwPad1 |= (1 << 6);
            break;
            
        case 'k':   /* right */
            *pdwPad1 |= (1 << 7);
            break;
            
        default:
            break;
        }
      }
  } else {
      times++;
      if (times > 5) {
          times = 0;
          *pdwPad1   = 0;
          *pdwPad1   = 0;
          *pdwSystem = 0;
      }
  }
  
  _G_dwPad1   = *pdwPad1;
  _G_dwPad2   = *pdwPad2;
  
  if (_G_dwSystem & PAD_SYS_QUIT) {
      _G_dwSystem = *pdwSystem | PAD_SYS_QUIT;
  } else {
      _G_dwSystem = *pdwSystem;
  }
  
  *pdwPad1 = *pdwPad1 | ( *pdwPad1 << 8 );
}
/*===================================================================*/
/*                                                                   */
/*             InfoNES_MemoryCopy() : memcpy                         */
/*                                                                   */
/*===================================================================*/
void *InfoNES_MemoryCopy( void *dest, const void *src, int count )
{
/*
 *  memcpy
 *
 *  Parameters
 *    void *dest                       (Write)
 *      Points to the starting address of the copied block�fs destination
 *
 *    const void *src                  (Read)
 *      Points to the starting address of the block of memory to copy
 *
 *    int count                        (Read)
 *      Specifies the size, in bytes, of the block of memory to copy
 *
 *  Return values
 *    Pointer of destination
 */

  memcpy( dest, src, count );
  return dest;
}
/*===================================================================*/
/*                                                                   */
/*            InfoNES_Wait() : Wait Emulation if required            */
/*                                                                   */
/*===================================================================*/
void InfoNES_Wait()
{
  //Lw_Time_Sleep(LW_OPTION_WAIT_A_TICK);
}

/*===================================================================*/
/*                                                                   */
/*                  InfoNES_Menu() : Menu screen                     */
/*                                                                   */
/*===================================================================*/
int InfoNES_Menu()
{
/*
 *  Menu screen
 *
 *  Return values
 *     0 : Normally
 *    -1 : Exit InfoNES
 */

  if (_G_bNesRunning) {
    return 0;
  } else {
    return -1;
  }
}

/*===================================================================*/
/*                                                                   */
/*        InfoNES_SoundInit() : Sound Emulation Initialize           */
/*                                                                   */
/*===================================================================*/
void InfoNES_SoundInit( void ) {

}

/*===================================================================*/
/*                                                                   */
/*        InfoNES_SoundOpen() : Sound Open                           */
/*                                                                   */
/*===================================================================*/
int InfoNES_SoundOpen( int samples_per_sync, int sample_rate ) 
{
/*
  lpSndDevice = new DIRSOUND( hWndMain );

  if ( !lpSndDevice->SoundOpen( samples_per_sync, sample_rate ) )
  {
    InfoNES_MessageBox( "SoundOpen() Failed." );
    exit(0);
  }

  // if sound mute, stop sound
  if ( APU_Mute )
  {
    if (!lpSndDevice->SoundMute( APU_Mute ) )
    {
      InfoNES_MessageBox( "SoundMute() Failed." );
      exit(0);
    }
  }
*/
  return(TRUE);
}

/*===================================================================*/
/*                                                                   */
/*        InfoNES_SoundClose() : Sound Close                         */
/*                                                                   */
/*===================================================================*/
void InfoNES_SoundClose( void ) 
{
/*
  lpSndDevice->SoundClose();
  delete lpSndDevice;
*/
}

/*===================================================================*/
/*                                                                   */
/*            InfoNES_SoundOutput4() : Sound Output 4 Waves          */           
/*                                                                   */
/*===================================================================*/
void InfoNES_SoundOutput( int samples, BYTE *wave1, BYTE *wave2, BYTE *wave3, BYTE *wave4, BYTE *wave5 ) 
{
/*
  BYTE wave[ rec_freq ];
  
  for ( int i = 0; i < rec_freq; i++)
  {
    wave[i] = ( wave1[i] + wave2[i] + wave3[i] + wave4[i] ) >> 2;
  }

  if (!lpSndDevice->SoundOutput( samples, wave ) )
  {
    InfoNES_MessageBox( "SoundOutput() Failed." );
    exit(0);
  }
*/
}

/*===================================================================*/
/*                                                                   */
/*            InfoNES_MessageBox() : Print System Message            */
/*                                                                   */
/*===================================================================*/
void InfoNES_MessageBox( char *pszMsg, ... )
{
    va_list     varlist;
    
    va_start(varlist, pszMsg);
    
    vprintf(pszMsg, varlist);
    
    va_end(varlist);
}

/*===================================================================*/
/*                                                                   */
/*           LoadSRAM() : Load a SRAM                                */
/*                                                                   */
/*===================================================================*/
int LoadSRAM()
{
/*
 *  Load a SRAM
 *
 *  Return values
 *     0 : Normally
 *    -1 : SRAM data couldn't be read
 */

  FILE *fp;
  unsigned char chData;
  unsigned char chTag;
  int nRunLen;
  int nDecoded;
  int nDecLen;
  int nIdx;

  // It doesn't need to save it
  nSRAM_SaveFlag = 0;

  // It is finished if the ROM doesn't have SRAM
  if ( !ROM_SRAM )
    return 0;

  // There is necessity to save it
  nSRAM_SaveFlag = 1;

  // The preparation of the SRAM file name
  strcpy( szSaveName, szRomName );
  strcpy( strrchr( szSaveName, '.' ) + 1, "srm" );

  /*-------------------------------------------------------------------*/
  /*  Read a SRAM data                                                 */
  /*-------------------------------------------------------------------*/

  // Open SRAM file
  fp = fopen( szSaveName, "rb" );
  if ( fp == NULL )
    return -1;

  // Read SRAM data
  fread( szLoadRamBuffer, SRAM_SIZE, 1, fp );

  // Close SRAM file
  fclose( fp );

  /*-------------------------------------------------------------------*/
  /*  Extract a SRAM data                                              */
  /*-------------------------------------------------------------------*/

  nDecoded = 0;
  nDecLen = 0;

  chTag = szLoadRamBuffer[ nDecoded++ ];

  while ( nDecLen < 8192 )
  {
    chData = szLoadRamBuffer[ nDecoded++ ];

    if ( chData == chTag )
    {
      chData = szLoadRamBuffer[ nDecoded++ ];
      nRunLen = szLoadRamBuffer[ nDecoded++ ];
      for ( nIdx = 0; nIdx < nRunLen + 1; ++nIdx )
      {
        SRAM[ nDecLen++ ] = chData;
      }
    }
    else
    {
      SRAM[ nDecLen++ ] = chData;
    }
  }

  // Successful
  return 0;
}

/*===================================================================*/
/*                                                                   */
/*           SaveSRAM() : Save a SRAM                                */
/*                                                                   */
/*===================================================================*/
int SaveSRAM()
{
/*
 *  Save a SRAM
 *
 *  Return values
 *     0 : Normally
 *    -1 : SRAM data couldn't be written
 */

  FILE *fp;
  int nUsedTable[ 256 ];
  unsigned char chData;
  unsigned char chPrevData;
  unsigned char chTag;
  int nIdx;
  int nEncoded;
  int nEncLen;
  int nRunLen;

  if ( !nSRAM_SaveFlag )
    return 0;  // It doesn't need to save it

  /*-------------------------------------------------------------------*/
  /*  Compress a SRAM data                                             */
  /*-------------------------------------------------------------------*/

  memset( nUsedTable, 0, sizeof nUsedTable );

  for ( nIdx = 0; nIdx < SRAM_SIZE; ++nIdx )
  {
    ++nUsedTable[ SRAM[ nIdx++ ] ];
  }
  for ( nIdx = 1, chTag = 0; nIdx < 256; ++nIdx )
  {
    if ( nUsedTable[ nIdx ] < nUsedTable[ chTag ] )
      chTag = nIdx;
  }

  nEncoded = 0;
  nEncLen = 0;
  nRunLen = 1;

  szSaveRamBuffer[ nEncLen++ ] = chTag;

  chPrevData = SRAM[ nEncoded++ ];

  while ( nEncoded < SRAM_SIZE && nEncLen < SRAM_SIZE - 133 )
  {
    chData = SRAM[ nEncoded++ ];

    if ( chPrevData == chData && nRunLen < 256 )
      ++nRunLen;
    else
    {
      if ( nRunLen >= 4 || chPrevData == chTag )
      {
        szSaveRamBuffer[ nEncLen++ ] = chTag;
        szSaveRamBuffer[ nEncLen++ ] = chPrevData;
        szSaveRamBuffer[ nEncLen++ ] = nRunLen - 1;
      }
      else
      {
        for ( nIdx = 0; nIdx < nRunLen; ++nIdx )
          szSaveRamBuffer[ nEncLen++ ] = chPrevData;
      }

      chPrevData = chData;
      nRunLen = 1;
    }

  }
  if ( nRunLen >= 4 || chPrevData == chTag )
  {
    szSaveRamBuffer[ nEncLen++ ] = chTag;
    szSaveRamBuffer[ nEncLen++ ] = chPrevData;
    szSaveRamBuffer[ nEncLen++ ] = nRunLen - 1;
  }
  else
  {
    for ( nIdx = 0; nIdx < nRunLen; ++nIdx )
      szSaveRamBuffer[ nEncLen++ ] = chPrevData;
  }

  /*-------------------------------------------------------------------*/
  /*  Write a SRAM data                                                */
  /*-------------------------------------------------------------------*/

  // Open SRAM file
  fp = fopen( szSaveName, "wb" );
  if ( fp == NULL )
    return -1;

  // Write SRAM data
  fwrite( szSaveRamBuffer, nEncLen, 1, fp );

  // Close SRAM file
  fclose( fp );

  // Successful
  return 0;
}
/*===================================================================*/
/*                                                                   */
/*        InfoNES_Start                                              */
/*                                                                   */
/*===================================================================*/
extern "C" {

static int      _G_iFdFrameBuffer = -1;

int  InfoNES_Start (int argc,  char  *argv[])
{
#if LW_CFG_GRAPH_EN > 0

    LW_GM_SCRINFO       gmsi;
    CPCHAR              pcPadName = "/dev/ttyS0";

    if (argc < 2) {
        printf("argument error.\n");
        return  (-1);
    }
    
    if (access(argv[1], 0) < 0) {
        printf("can not access file.\n");
        return  (-1);
    }
    
    if (_G_iFdFrameBuffer < 0) {
        _G_iFdFrameBuffer = open("/dev/fb0", O_RDWR);
        if (_G_iFdFrameBuffer < 0) {
            printf("can not /dev/fb0 framebuffer device.\n");
            return  (-1);
        }
    }
    if (ioctl(_G_iFdFrameBuffer, LW_GM_GET_SCRINFO, &gmsi) < 0) {
        printf("can read framebuffer info.\n");
        return  (-1);
    }
    
    if (argc > 2) {
        pcPadName = argv[2];
    }
    if (_G_iPadTty < 0) {
        _G_iPadTty = open(pcPadName, O_RDONLY);
        ioctl(_G_iPadTty, FIOSETOPTIONS, (void *)(OPT_RAW));
    }
    
    if ((argc > 3) && (argv[3][0] != '0')) {
        _G_i2XDisp = 1;
    } else {
        _G_i2XDisp = 0;
    }
     
    _G_pcFrameBuffer  = gmsi.GMSI_pcMem;
    _G_ulBytesPerLine = gmsi.GMSI_stMemSizePerLine;
    
    _G_dwPad1   = 0;
    _G_dwPad2   = 0;
    _G_dwSystem = 0;
    /*
     *  TODO: װ�� *.srm ��¼�ļ�
     */
    _G_bNesRunning = TRUE;
    if (InfoNES_Load(argv[1]) == 0) {
        strcpy( szRomName, argv[1] );
        LoadSRAM();
        InfoNES_Main();
    }
#endif  /* LW_CFG_GRAPH_EN > 0 */

    return  (0);
}

int  InfoNES_End (int argc,  char  *argv[])
{
#if LW_CFG_GRAPH_EN > 0

    _G_bNesRunning   = FALSE;
    _G_pcFrameBuffer = NULL;
    
    SaveSRAM();
    _G_dwSystem = PAD_SYS_QUIT;
    
    if (_G_iFdFrameBuffer >= 0) {
        close(_G_iFdFrameBuffer);
        _G_iFdFrameBuffer = -1;
    }
    
    if (_G_iPadTty >= 0) {
        close(_G_iPadTty);
        _G_iPadTty = -1;
    }
#endif  /* LW_CFG_GRAPH_EN > 0 */
    
    return  (0);
}

}
/*********************************************************************************************************
  END
*********************************************************************************************************/
