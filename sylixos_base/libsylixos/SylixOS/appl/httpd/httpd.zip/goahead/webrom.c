/*
 * webrom.c -- Compiled Web Pages
 *
 * Copyright (c) GoAhead Software Inc., 1995-2000. All Rights Reserved.
 *
 * See the file "license.txt" for usage and redistribution license requirements
 *
 * $Id: webrom.c,v 1.3 2002/10/24 14:44:50 bporter Exp $
 */

#include "wsIntrn.h"

websRomPageIndexType websRomPageIndex[] = {
  { 0, 0, 0 },
};

